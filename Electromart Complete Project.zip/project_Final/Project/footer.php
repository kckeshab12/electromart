<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ElectroMart</title>
    <!-- Bootstrap CSS link -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <!-- Font Awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .form-control {
            width: 300px; /* Increase the width of the search input */
        }

        .site-footer {
            background-color: #26272b;
            padding: 45px 0 20px;
            font-size: 15px;
            line-height: 24px;
            color: #737373;
        }
        .site-footer hr {
            border-top-color: #bbb;
            opacity: 0.5;
        }
        .site-footer hr.small {
            margin: 20px 0;
        }
        .site-footer h6 {
            color: #fff;
            font-size: 16px;
            text-transform: uppercase;
            margin-top: 5px;
            letter-spacing: 2px;
        }
        .site-footer a {
            color: #737373;
        }
        .site-footer a:hover {
            color: #3366cc;
            text-decoration: none;
        }
        .footer-links {
            padding-left: 0;
            list-style: none;
        }
        .footer-links li {
            display: block;
        }
        .footer-links a {
            color: #737373;
        }
        .footer-links a:active, .footer-links a:focus, .footer-links a:hover {
            color: #3366cc;
            text-decoration: none;
        }
        .footer-links.inline li {
            display: inline-block;
        }
        .site-footer .social-icons {
            text-align: right;
        }
        .site-footer .social-icons a {
            width: 40px;
            height: 40px;
            line-height: 40px;
            margin-left: 6px;
            margin-right: 0;
            border-radius: 100%;
            background-color: #33353d;
            color: #fff;
            font-size: 20px;
            display: inline-block;
            text-align: center;
            margin-right: 8px;
            transition: all 0.2s linear;
        }
        .site-footer .social-icons a:hover {
            color: #fff;
            background-color: #29aafe;
        }
        @media (max-width: 991px) {
            .site-footer [class^=col-] {
                margin-bottom: 30px;
            }
        }
        @media (max-width: 767px) {
            .site-footer {
                padding-bottom: 0;
            }
            .site-footer .copyright-text, .site-footer .social-icons {
                text-align: center;
            }
        }
        .social-icons {
            padding-left: 0;
            margin-bottom: 0;
            list-style: none;
        }
        .social-icons li {
            display: inline-block;
            margin-bottom: 4px;
        }
        .social-icons li.title {
            margin-right: 15px;
            text-transform: uppercase;
            color: #96a2b2;
            font-weight: 700;
            font-size: 13px;
        }
        .social-icons.size-sm a {
            line-height: 34px;
            height: 34px;
            width: 34px;
            font-size: 14px;
        }
        .social-icons a.facebook:hover {
            background-color: #3b5998;
        }
        .social-icons a.twitter:hover {
            background-color: #00aced;
        }
        .social-icons a.linkedin:hover {
            background-color: #007bb6;
        }
        .social-icons a.instagram:hover {
            background-color: #bc2a8d;
        }
        .social-icons a.github:hover {
            background-color: #333;
        }
        @media (max-width: 767px) {
            .social-icons li.title {
                display: block;
                margin-right: 0;
                font-weight: 600;
            }
        }
    </style>
</head>
<body>

<!-- Footer -->
<footer id="footer" class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-8 mb-4">
                <h6>ABOUT US</h6>
                <p class="text-justify">At ElectroMart, we are dedicated to bringing you the latest and greatest in electronic products. From cutting-edge gadgets to essential home appliances, our mission is to offer a diverse range of high-quality products that cater to your every need. With a commitment to customer satisfaction, we ensure a seamless shopping experience backed by exceptional customer service. Explore our extensive collection and discover the future of technology with ElectroMart.</p>
            </div>

            <div class="col-xs-6 col-md-4 mb-4">
                <h6>Quick Links</h6>
                <ul class="footer-links">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="contact_us.php">Contact Us</a></li>
                    <li><a href="product_details.php">Products</a></li>
                    <li><a href="search_product.php">Search</a></li>
                </ul>
            </div>
        </div>
        <hr>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-sm-6 col-xs-12">
                <p class="copyright-text">Copyright &copy; 2024 All Rights Reserved by 
                    <a href="#">ElectroMart Team</a>.
                </p>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
                <ul class="social-icons">
                    <li><a class="facebook" href="https://www.facebook.com/profile.php?id=100064047611334"><i class="fab fa-facebook"></i></a></li>
                    <li><a class="twitter" href="https://twitter.com/KeshabKc557932"><i class="fab fa-twitter"></i></a></li>
                    <li><a class="instagram" href="https://www.instagram.com/ni_sh_ant_u/"><i class="fab fa-instagram"></i></a></li>
                    <li><a class="linkedin" href="https://www.linkedin.com/in/keshab-kc-33a099259/"><i class="fab fa-linkedin"></i></a></li>   
                    <li><a class="github" href="https://github.com/nishanttimalsina"><i class="fab fa-github"></i></a></li> 
                </ul>
            </div>
        </div>
    </div>
</footer>
<!-- End of Footer -->

<!-- Bootstrap JS link -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
</body>
</html>
