<?php
if(isset($_GET['delete_payments'])){
    $delete_id = $_GET['delete_payments'];
?>

<script>
    if(confirm("Are you sure you want to delete this payment?")){
        <?php
            $delete_product = "DELETE FROM `user_payment` WHERE order_id = $delete_id";
            $result_product = mysqli_query($con, $delete_product);
            if($result_product){
                echo "alert('Payment deleted successfully');";
                echo "window.open('./index.php?list_payments','_self');";
            }
            else {
                echo "alert('Error: Unable to delete payment');";
            }
        ?>
    }
    else {
        // Do nothing if the user clicks "Cancel"
    }
</script>

<?php
}
?>