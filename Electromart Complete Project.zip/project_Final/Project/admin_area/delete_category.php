<?php
if(isset($_GET['delete_category'])){
    $delete_category=$_GET['delete_category'];
?>

<script>
    if(confirm("Are you sure you want to delete this category?")){
        <?php
            $delete_query="DELETE FROM `categorie` WHERE category_id=$delete_category";
            $result=mysqli_query($con,$delete_query);
            if($result){
                echo "alert('Category deleted successfully');";
                echo "window.open('./index.php?view_categories','_self');";
            } else {
                echo "alert('Failed to delete category');";
                echo "window.open('./index.php?view_categories','_self');";
            }
        ?>
    }
    else {
        // Do nothing if the user clicks "Cancel"
    }
</script>

<?php
}
?>
