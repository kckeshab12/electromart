<?php
if(isset($_GET['delete_product'])){
    $delete_id = $_GET['delete_product'];
?>

<script>
    if(confirm("Are you sure you want to delete this product?")){
        <?php
            $delete_product = "DELETE FROM `product` WHERE product_id = $delete_id";
            $result_product = mysqli_query($con, $delete_product);
            if($result_product){
                echo "alert('Product deleted successfully');";
                echo "window.location='./index.php';";
            }
            else {
                echo "alert('Error: Unable to delete product');";
            }
        ?>
    }
    else {
        // Do nothing if the user clicks "Cancel"
    }
</script>

<?php
}
?>