<?php
if(isset($_GET['delete_brands'])){
    $delete_brands=$_GET['delete_brands'];
    // echo $delete_category;
?>

<script>
    if(confirm("Are you sure you want to delete this brand?")){
        <?php
            $delete_query="DELETE FROM `brand` WHERE brand_id=$delete_brands";
            $result=mysqli_query($con,$delete_query);
            if($result){
                echo "alert('Brand deleted successfully');";
                echo "window.open('./index.php?view_brands','_self');";
            } else {
                echo "alert('Failed to delete brand');";
            }
        ?>
    }
    else {
        window.open('./index.php?view_brands','_self');
    }
</script>

<?php
}
?>
