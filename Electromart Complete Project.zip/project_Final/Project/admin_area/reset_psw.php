<?php
session_start();
include('connection.php'); // Ensure this path is correct

if (isset($_POST["reset"])) {
    $psw = $_POST["password"];
    $token = $_SESSION['token'];
    $Email = $_SESSION['admin_email'];
    $hash = password_hash($psw, PASSWORD_DEFAULT);

    // Check if the email and token are set
    if (isset($Email) && isset($token)) {
        $sql = $conn->prepare("SELECT * FROM admin_table WHERE admin_email = ?");
        $sql->bind_param("s", $Email);
        $sql->execute();
        $result = $sql->get_result();

        if ($result) {
            $query = $result->num_rows;
            $fetch = $result->fetch_assoc();

            if ($query > 0) {
                $new_pass = $hash;
                $update_sql = $conn->prepare("UPDATE admin_table SET password = ? WHERE admin_email = ?");
                $update_sql->bind_param("ss", $new_pass, $Email);
                
                if ($update_sql->execute()) {
                    session_unset();
                    session_destroy();
                    echo "<script>alert('Your password has been successfully reset'); window.location.replace('admin_login.php');</script>";
                } else {
                    echo "<script>alert('Failed to reset password. Please try again.');</script>";
                }
            } else {
                echo "<script>alert('Email not found.');</script>";
            }
        } else {
            echo "<script>alert('Database query failed.');</script>";
        }
    } else {
        echo "<script>alert('Invalid token or email.');</script>";
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />

    <title>Login Form</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="#">Password Reset Form</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<main class="login-form">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Reset Your Password</div>
                    <div class="card-body">
                        <form action="#" method="POST" name="login">
                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-right">New Password</label>
                                <div class="col-md-6">
                                    <input type="password" id="password" class="form-control" name="password" required autofocus>
                                    <i class="bi bi-eye-slash" id="togglePassword"></i>
                                </div>
                            </div>
                            <div class="col-md-6 offset-md-4">
                                <input type="submit" value="Reset" name="reset">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
    const toggle = document.getElementById('togglePassword');
    const password = document.getElementById('password');

    toggle.addEventListener('click', function() {
        if (password.type === "password") {
            password.type = 'text';
        } else {
            password.type = 'password';
        }
        this.classList.toggle('bi-eye');
    });
</script>
</body>
</html>
