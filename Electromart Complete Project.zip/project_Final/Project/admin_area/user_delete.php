<?php
if (isset($_GET['user_delete'])) {
    $user_delete = $_GET['user_delete'];
?>

<script>
    if (confirm("Are you sure you want to delete this user?")) {
        <?php
        $delete_query = "DELETE FROM `user_tables` WHERE user_id = $user_delete";
        $result = mysqli_query($con, $delete_query);
        
        if ($result) {
            echo "alert('User deleted successfully');";
            echo "window.open('./index.php?list_users','_self');";
        } else {
            echo "alert('Error: Unable to delete user');";
        }
        ?>
    }
</script>

<?php
}
?>
