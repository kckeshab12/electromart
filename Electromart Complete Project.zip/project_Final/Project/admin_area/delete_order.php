<?php
if (isset($_GET['delete_order'])) {
    $delete_order = $_GET['delete_order'];
?>

<script>
    if(confirm("Are you sure you want to delete this order?")){
        <?php
            $delete_query = "DELETE FROM `user_order` WHERE order_id = $delete_order";
            $result = mysqli_query($con, $delete_query);

            if ($result) {
                echo "alert('Order deleted successfully');";
                echo "window.open('./index.php?list_orders','_self');";
            } else {
                echo "alert('Error: Unable to delete order');";
            }
        ?>
    }
    else {
        // Do nothing if the user clicks "Cancel"
    }
</script>

<?php
}
?>
