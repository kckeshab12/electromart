<?php 
session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="style.css">

    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Login Form</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="#">User Password Recover</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
</nav>

<main class="login-form">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Password Recover</div>
                    <div class="card-body">
                        <form action="#" method="POST" name="recover_psw">
                            <div class="form-group row">
                                <label for="email_address" class="col-md-4 col-form-label text-md-right">E-Mail Address</label>
                                <div class="col-md-6">
                                    <input type="email" id="email_address" class="form-control" name="email" required autofocus>
                                </div>
                            </div>
                            <div class="col-md-6 offset-md-4">
                                <input type="submit" value="Recover" name="recover">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
</body>
</html>

<?php

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include database connection details (replace with your actual details)
require_once('connection.php');

if (isset($_POST["recover"])) {
    $email = $_POST["email"];

    // Check for database connection
    if (!$conn) {
        echo "Error: Connection failed!";
        exit();  // Terminate script execution
    }

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin_table WHERE admin_email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Generate a random token
        $token = bin2hex(random_bytes(50));

        // Generate a random string for the link
        $random_string = bin2hex(random_bytes(16));

        // Insert the random string and token into the reset_tokens table (replace with your table name)
        $stmt = $conn->prepare("INSERT INTO reset_tokens (email, token, random_string) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $token, $random_string);

        if (!$stmt->execute()) {
            echo "Error inserting token: " . $stmt->error;
        } else {
            // Create the link with the random string
            $reset_link = "http://localhost/project/admin_area/reset_psw.php?token=" . $random_string;

            // Configure PHPMailer
            require 'C:\xampp\htdocs\Project\vendor\autoload.php';

            $mail = new PHPMailer\PHPMailer\PHPMailer;

            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 465;
            $mail->SMTPAuth = true;
            $mail->SMTPSecure = 'ssl';  // Use SSL encryption

            $mail->Username = 'timalsinanishant01@gmail.com';  // Your Gmail address
            $mail->Password = 'hlqc kjyb pbmn aybo';  // Your Gmail password

            $mail->SMTPDebug = 2;  // Enable debug output

            $mail->setFrom('timalsinanishant01@gmail.com', 'Password Reset');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = "Recover your password";
            $mail->Body = "<b>Dear User</b>
              <h3>We received a request to reset your password.</h3>
              <p>Kindly click the below link to reset your password</p>
              <a href='$reset_link'>Reset Password</a>
              <br><br>
              <p>With regards,</p>
              <b>ElectroMart Team</b>";

            if (!$mail->send()) {
                echo "Error sending email: " . $mail->ErrorInfo;
            } else {
                ?>
                <script>
                    alert("A password reset link has been sent to your email address.");
                    window.location.replace("notification.html");
                </script>
                <?php
            }
        }
    } else {
        ?>
        <script>
            alert("Sorry, no emails exist.");
        </script>
        <?php
    }
    $stmt->close();  // Close prepared statement
}

$conn->close();  // Close database connection
?>
