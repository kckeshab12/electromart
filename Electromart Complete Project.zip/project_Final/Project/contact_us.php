<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electro</title>
    <style>
        body {
            background: url('user_area/user_images/feedback.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .contact-form {
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        .contact-form h6 {
            margin-bottom: 20px;
            text-align: center;
        }
        .form_field {
            margin-bottom: 15px;
        }
        .form_container {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form_container:focus {
            border-color: #3366cc;
            outline: none;
        }
        .form_field button {
            background-color: #3366cc;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }
        .form_field button:hover {
            background-color: #254a8a;
        }
    </style>
</head>
<body>
    <div class="contact-form">
        <h6>CONTACT US</h6>
        <form id="feedbackForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form_field">
                <input type="text" class="form_container" id="contact_name" name="contact_name" placeholder="Name" required>
            </div>
            <div class="form_field">
                <input type="text" class="form_container" id="address" name="address" placeholder="Address" required>
            </div>
            <div class="form_field">
                <input type="email" class="form_container" id="email" name="email" placeholder="Email" required>
            </div>
            <div class="form_field">
                <input type="number" class="form_container" id="number" name="number" placeholder="Number" required>
            </div>
            <div class="form_field">
                <textarea class="form_container" id="message" name="message" placeholder="Message to us" required></textarea>
            </div>
            <div class="form_field">
                <button type="submit" name="submit">Send Message</button>
            </div>
        </form>
    </div>

    <script>
        // JavaScript code to show a popup message
        document.getElementById('feedbackForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent default form submission

            // Display popup message
            var popup = document.createElement('div');
            popup.textContent = 'Thank you! Your feedback has been submitted successfully.';
            popup.style.backgroundColor = 'rgb(0,128,0)';
            popup.style.color = 'white';
            popup.style.padding = '10px';
            popup.style.borderRadius = '5px';
            popup.style.position = 'fixed';
            popup.style.top = '10%';
            popup.style.left = '50%';
            popup.style.transform = 'translate(-50%, -50%)';
            popup.style.zIndex = '9999';
            document.body.appendChild(popup);

            // Close the popup after 3 seconds
            setTimeout(function() {
                document.body.removeChild(popup);
            }, 3000);

            // Submit the form
            this.submit();
        });
    </script>
</body>
</html>

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mystore";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $contact_name = $_POST['contact_name'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $message = $_POST['message'];
    
    $sql = "INSERT INTO feedback (contact_name, address, email, number, message) VALUES ('$contact_name', '$address', '$email', '$number', '$message')";
    
    if ($conn->query($sql) === TRUE) {
        // No need to echo the success message here as it is displayed using JavaScript
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>